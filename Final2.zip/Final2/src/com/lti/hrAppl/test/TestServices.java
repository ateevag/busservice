package com.lti.hrAppl.test;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.hrAppl.daos.RouteDao;
import com.lti.hrAppl.daos.RouteDaoImpl;
import com.lti.hrAppl.entities.BusDetails;
import com.lti.hrAppl.entities.BusRoute;
import com.lti.hrAppl.entities.TravelDayDetails;
import com.lti.hrAppl.exceptions.BusExceptions;
import com.lti.hrAppl.services.BookingSeatServices;
import com.lti.hrAppl.services.SearchBus;

public class TestServices {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");

	/*	SearchBus services = (SearchBus) ctx.getBean("searchBus");
		 List<BusDetails> busDetails = services.findByRouteID("lonavala","mumbai", "Thursday"); 
		 for(BusDetails br : busDetails) {
			 System.out.println(br.getRouteId());
			 System.out.println(br.getProviderName());
		 }*/
		
		
		BookingSeatServices services = (BookingSeatServices) ctx.getBean("bookingSeatServices");
		try {
		 services.save("MH-12-C-6849","3","mike22@gmail.com","20/Mar/2018","22/Mar/2018","1200","Confirmed");
		}
		
		catch(BusExceptions e)
		{
			System.out.println("Seat Booking Error");
			e.printStackTrace();
		}
		
		/*try {
			services.saveSeat("3", "12,13,14", "nishi,palak,ayushi", "F,F,F", "12,22,20", 3);
			}
			
			catch(BusExceptions e)
			{
				System.out.println("Seat Booking Error");
				e.printStackTrace();
			}
		*/
		
	}

}
