package com.lti.hrAppl.daos;

import java.util.List;

import com.lti.hrAppl.entities.BoardingDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface BoardingDetailsDao {
	public List<String> findBoardingDetails(String busNo) throws BusExceptions;
	
	public List<String> findArrivalDetails(String busNo) throws BusExceptions;
}
