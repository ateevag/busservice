package com.lti.hrAppl.daos;

import java.util.List;

import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface BookingDao {

    Integer save(String busNo, String noOfSeats, String emailId, String bookingDate, String travelDate, String totalFare, String bookingStatus) throws BusExceptions;
	Booking findByBookingId(Integer bookingId) throws BusExceptions;
	void updateBooking(Integer bookingId) throws BusExceptions;
	List<Booking> findByBusNoTravelDate(String busNo, String travelDate) throws BusExceptions;

}
