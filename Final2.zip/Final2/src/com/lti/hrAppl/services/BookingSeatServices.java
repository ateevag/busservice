package com.lti.hrAppl.services;

import java.util.List;

import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.entities.SeatDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface BookingSeatServices {
	
	Integer save(String busNo, String noOfSeats, String emailId, String bookingDate, String travelDate, String totalFare, String bookingStatus)throws BusExceptions;
	/*Booking findByBookingId(Integer bookingId); throws BusExceptions*/
	void updateBooking(Integer bookingId) throws BusExceptions;
	List<Booking> findByBusNoTravelDate(String busNo, String travelDate) throws BusExceptions;

	List<SeatDetails> findByBookingId(Integer bookingId) throws BusExceptions;
	void saveSeat(String bookingId, String seatNo, String passengerName, String gender, String age, Integer number) throws BusExceptions;
	void deleteBooking(Integer bookingId) throws BusExceptions;
	
	
}
