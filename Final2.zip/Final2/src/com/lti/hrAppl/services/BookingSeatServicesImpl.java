package com.lti.hrAppl.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hrAppl.daos.BoardingDetailsDao;
import com.lti.hrAppl.daos.BookingDao;
import com.lti.hrAppl.daos.SeatDetailsDao;
import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.entities.SeatDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

@Service("bookingSeatServices")
public class BookingSeatServicesImpl implements BookingSeatServices {

	@Autowired
	private BookingDao bdao;
	
	@Autowired
	private SeatDetailsDao sdao;
	
	@Override
	public Integer save(String busNo, String noOfSeats, String emailId, String bookingDate, String travelDate, String totalFare, String bookingStatus) throws BusExceptions{
		Integer bookID=bdao.save(busNo, noOfSeats, emailId, bookingDate, travelDate, totalFare, bookingStatus);
		return bookID;
	}

	@Override
	public void updateBooking(Integer bookingId) throws BusExceptions {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Booking> findByBusNoTravelDate(String busNo, String travelDate) throws BusExceptions {
		
		return bdao.findByBusNoTravelDate(busNo, travelDate);
	}

	@Override
	public List<SeatDetails> findByBookingId(Integer bookingId) throws BusExceptions{
		
		return sdao.findByBookingId(bookingId);
	}

	@Override
	public void saveSeat(String bookingId, String seatNo, String passengerName, String gender, String age, Integer number) throws BusExceptions {
		sdao.saveSeat(bookingId, seatNo, passengerName, gender, age, number);
		
	}

	@Override
	public void deleteBooking(Integer bookingId) throws BusExceptions{
		// TODO Auto-generated method stub
		
	}

	
	
	

}
