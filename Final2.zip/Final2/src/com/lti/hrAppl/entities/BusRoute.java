package com.lti.hrAppl.entities;

import java.io.Serializable;
import javax.persistence.*;


@Entity
@Table(name="route")
public class BusRoute implements Serializable {
	
	@Id
	@Column(name="route_Id")
	private String routeId;
	
	@Column(name="source")
	private String source;
	
	@Column(name="destination")
	private String destination;

	public String getRouteId() {
		return routeId;
	}

	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "BusRoute [routeId=" + routeId + ", source=" + source + ", destination=" + destination + "]";
	}
	
	
}
