package com.lti.hrAppl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seat_Details")
public class SeatDetails implements Serializable {

	
@Id
@Column(name="booking_Id")
private String bookingId;

@Id
@Column(name="seat_No")
private String seatNo;

@Column(name="passenger_Name")
private String passengerName;

@Column(name="gender")
private String gender;

@Column(name="age")
private String age;

public String getBookingId() {
	return bookingId;
}

public void setBookingId(String bookingId) {
	this.bookingId = bookingId;
}

public String getSeatNo() {
	return seatNo;
}

public void setSeatNo(String seatNo) {
	this.seatNo = seatNo;
}

public String getPassengerName() {
	return passengerName;
}

public void setPassengerName(String passengerName) {
	this.passengerName = passengerName;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getAge() {
	return age;
}

public void setAge(String age) {
	this.age = age;
}
	
	

}
