package com.lti.hrAppl.exceptions;

public class BusExceptions extends Exception {
public BusExceptions() {
		
	}

	public BusExceptions(String message) throws BusExceptions {
		super(message);
		
	}
	
	public BusExceptions(String message, Throwable cause) throws BusExceptions {
		super(message, cause);
		
	}


}
