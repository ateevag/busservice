package com.lti.hrAppl.entities;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="booking")
public class Booking implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="booking_Id")
	private Integer bookingId;
	
	@Column(name="bus_No")
	private String busNo;

	@Column(name="no_Of_Seats")
	private String noOfSeats;
	
	@Column(name="email_Id")
	private String emailId;

	@Column(name="booking_Date")
	private String bookingDate;
	
	@Column(name="travel_Date")
	private String travelDate;
	
	@Column(name="total_Fare")
	private String totalFare;
	
	@Column(name="booking_Status")
	private String bookingStatus;

	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public String getBusNo() {
		return busNo;
	}

	public void setBusNo(String busNo) {
		this.busNo = busNo;
	}

	public String getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(String noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(String travelDate) {
		this.travelDate = travelDate;
	}

	public String getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(String totalFare) {
		this.totalFare = totalFare;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	
	


	

}

