package com.lti.hrAppl.entities;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name="bus_Details")
public class BusDetails implements Serializable {
	
	@Id
	@Column(name="bus_no")
	private String busNo;
	
	
	@Column(name="route_id")
	private String routeId;
	
	@Column(name="provider_name")
	private String providerName;
	
	@Column(name="fare")
	private Integer fare;
	
	@Column(name="bus_category")
	private String category;
	
	@Column(name="departure_time")
	private String deptTime;
	
	@Column(name="arrival_time")
	private String arrTime;
	
	public String getBusNo() {
		return busNo;
	}
	public void setBusNo(String busNo) {
		this.busNo = busNo;
	}
	public String getRouteId() {
		return routeId;
	}
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Integer getFare() {
		return fare;
	}
	public void setFare(Integer fare) {
		this.fare = fare;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDeptTime() {
		return deptTime;
	}
	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	@Override
	public String toString() {
		return "BusDetails [busNo=" + busNo + ", routeId=" + routeId + ", providerName=" + providerName + ", fare="
				+ fare + ", category=" + category + ", deptTime=" + deptTime + ", arrTime=" + arrTime + "]";
	}
	
	
	
}
