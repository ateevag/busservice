/**
 * 
 */
package com.lti.hrAppl.entities;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name="bus_days")
public class TravelDayDetails implements Serializable {

	@Id
	@Column(name="bus_No")
	private String busNo;

	@Id
	@Column(name="day")
	private String travelDay;

	public String getBusNo() {
		return busNo;
	}

	public void setBusNo(String busNo) {
		this.busNo = busNo;
	}

	public String getTravelDay() {
		return travelDay;
	}

	public void setTravelDay(String travelDay) {
		this.travelDay = travelDay;
	}

	@Override
	public String toString() {
		return "TravelDayDetails [busNo=" + busNo + ", travelDay=" + travelDay + "]";
	}
	
	
	
}
