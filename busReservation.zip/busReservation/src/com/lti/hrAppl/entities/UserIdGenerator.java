package com.lti.hrAppl.entities;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.persistence.NamedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.engine.spi.NamedSQLQueryDefinition;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class UserIdGenerator implements IdentifierGenerator{
	//private static int autoId = 1;

    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
    		String strId=null;
			String zeroAppend="";
			
			try {
				int nextVal = getNextValueFromSequence(session);
				strId = String.valueOf(nextVal);
				int strLen = strId.length();
				if (strId.length()<3){
					for(int idx=1; idx<= 3-strLen; idx++){
						zeroAppend += "0";
					}
				}
				//autoId++;
			} catch (SQLException e) {
				e.printStackTrace();
			}
            return "User"+ zeroAppend + strId;
    }
    
    private int getNextValueFromSequence(SessionImplementor session) throws SQLException{
    	Connection connect = session.connection();
    	int nextVal = 0;
    	Statement stmt = connect.createStatement();
    	ResultSet rs = stmt.executeQuery("select hibernate_sequence.nextval from Dual");
    	if (rs.next()){
    		nextVal = rs.getInt(1);
    		
    	}
    	return nextVal;
    }
}

