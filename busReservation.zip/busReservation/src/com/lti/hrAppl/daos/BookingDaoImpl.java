package com.lti.hrAppl.daos;

import java.util.List;
import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.exceptions.BusExceptions;

@Repository
public class BookingDaoImpl implements BookingDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public Integer save(String busNo, String noOfSeats, String emailId, String bookingDate, String travelDate, String totalFare, String bookingStatus) throws BusExceptions{
		Booking book = new Booking();
		Integer bookID;
		book.setBusNo(busNo);
		book.setNoOfSeats(noOfSeats);
		book.setEmailId(emailId);
		book.setBookingDate(bookingDate);
		book.setTravelDate(travelDate);
		book.setTotalFare(totalFare);
		book.setBookingStatus(bookingStatus);
		Session session=sessionFactory.openSession();
		Transaction t= session.getTransaction();
		t.begin();
		session.save(book);
		bookID=book.getBookingId();
		t.commit();
		session.close();
		return bookID;
	}

	@Override
	public Booking findByBookingId(Integer bookingId) throws BusExceptions {
		Session session = sessionFactory.openSession();
		Booking booking = (Booking) session.get(Booking.class, bookingId);
		session.close();
		return booking;
	}


	@Override
	public List<Booking> findByBusNoTravelDate(String busNo, String travelDate) throws BusExceptions {
		List<Booking> book= null;
		Session session= sessionFactory.openSession();
		Query query = session.createQuery("from Booking b where b.busNo like :busNo and b.travelDate like :travelDate");
		query.setParameter("busNo", busNo);
		query.setParameter("travelDate", travelDate);
		book=query.list();
		session.close();
		return book;
	}

	@Override
	public void updateBooking(Integer bookingId)  throws BusExceptions {
		String str= "cancelled";
		Session session = sessionFactory.openSession();
		Transaction t= session.getTransaction();
		t.begin();
		Query query = session.createQuery("UPDATE Booking b set b.bookingStatus =:bookingStatus WHERE b.bookingId =:bookingId").setParameter("bookingStatus", str).setParameter("bookingId", bookingId);
		query.executeUpdate(); 
		t.commit();
		//System.out.println("no. of rows affected are"+result);
		session.close();
		
	}
}

