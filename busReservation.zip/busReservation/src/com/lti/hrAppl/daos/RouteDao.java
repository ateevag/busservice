package com.lti.hrAppl.daos;

import java.util.List;

import com.lti.hrAppl.daos.*;/*
import com.gladiator.models.BusDetails;
import com.gladiator.models.BusRoute;
import com.gladiator.models.TravelDayDetails;
*/
import com.lti.hrAppl.entities.BusDetails;
import com.lti.hrAppl.entities.BusRoute;
import com.lti.hrAppl.entities.TravelDayDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface RouteDao {


	BusRoute findById(String routeId) throws BusExceptions;
	List<BusRoute> findBySourceName(String source, String destination) throws BusExceptions;
	List<BusDetails> findById2(String routeId) throws BusExceptions;
	List<TravelDayDetails> findByBusNo(String busNo) throws BusExceptions;
	List<BusDetails> findByRouteID(String source, String destination, String day) throws BusExceptions;
}
