package com.lti.hrAppl.daos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.*;
import  com.lti.hrAppl.entities.BoardingDetails;
import  com.lti.hrAppl.entities.Booking;
import  com.lti.hrAppl.entities.SeatDetails;
import com.lti.hrAppl.exceptions.BusExceptions;


@Repository
public class SeatDetailsDaoImpl implements SeatDetailsDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<SeatDetails> findByBookingId(Integer bookingId)  throws BusExceptions {
		Session session = sessionFactory.openSession();
		List<SeatDetails> seatDetails = null;
		Query query = session.createQuery("from SeatDetails sd where sd.bookingId like :bookingId").setParameter("bookingId", bookingId);
		seatDetails = query.list();
		session.close();
		return seatDetails;
	}
	
	
	@Override
	public void saveSeat(String bookingId, String seatNo, String passengerName, String gender, String age, Integer number)  throws BusExceptions  {

		Session session = sessionFactory.openSession();
		Transaction tn = session.getTransaction();
		List<SeatDetails> sd= new ArrayList<SeatDetails>();
		String seatno[]= null;
		seatno= seatNo.split(","); 
		
		String passName[]= null;
		passName= passengerName.split(","); 
		
		String passAge[]= null;
		passAge = age.split(","); 
		
		String passGender[]= null;
		passGender = gender.split(","); 
		
		
		
		try {
			tn.begin();
			for(int index=0;index<number;index++)
			{	
			SeatDetails seat= new SeatDetails();
			seat.setBookingId(bookingId);
			seat.setSeatNo(seatno[index]);
			seat.setPassengerName(passName[index]);
			seat.setGender(passGender[index]);
			seat.setAge(passAge[index]);
			session.persist(seat);
			}
			tn.commit();
			
		
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		session.close();
	
	}
	
	
	@Override
	public void deleteBooking(Integer bookingId)  throws BusExceptions{
		
		Session session = sessionFactory.openSession();
		Transaction t= session.getTransaction();
		t.begin();
		Query query = session.createQuery("delete from SeatDetails sd where sd.bookingId like :bookingId").setParameter("bookingId", bookingId);
		query.executeUpdate(); 
		t.commit();
		session.close();
		
	}
	
	

}
