package com.lti.hrAppl.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hrAppl.daos.CustomerDao;
import com.lti.hrAppl.entities.Customer;
import com.lti.hrAppl.exceptions.BusExceptions;


@Service("customerServices")
public class CustomerServicesImpl implements CustomerServices {

	@Autowired
	private CustomerDao custDao;
	
	@Override
	public void save(String email, String mobileNo, String custName, String password, String gender) throws BusExceptions{
		custDao.save(email, mobileNo, custName, password, gender);
	}

	@Override
	public List<Customer> findByEmailId(String email) throws BusExceptions{
		return custDao.findByEmailId(email);
	}

}
