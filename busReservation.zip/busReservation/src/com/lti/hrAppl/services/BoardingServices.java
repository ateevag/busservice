package com.lti.hrAppl.services;

import java.util.List;

import com.lti.hrAppl.exceptions.BusExceptions;

public interface BoardingServices {
public List<String> findBoardingDetails(String busNo) throws BusExceptions;
	
	public List<String> findArrivalDetails(String busNo) throws BusExceptions;
}
