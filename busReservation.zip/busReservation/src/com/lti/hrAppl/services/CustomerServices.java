package com.lti.hrAppl.services;

import java.util.List;

import com.lti.hrAppl.entities.Customer;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface CustomerServices {
	
	void save(String email, String mobileNo, String custName, String password, String gender) throws BusExceptions;
	List<Customer> findByEmailId(String email) throws BusExceptions; 

}
