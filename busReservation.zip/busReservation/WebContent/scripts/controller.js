var webmodule = angular.module("webmodule", ['ngRoute']);


webmodule.controller("myCtrl", function ($scope, $location, $rootScope) {

});

webmodule.config(

    function ($routeProvider) {
        $routeProvider

            .when('/home', {
                templateUrl: 'pages/home.html',
                controller: 'myCtrl'
            })

            .when('/about', {
                templateUrl: 'pages/about.html',
                controller: 'myCtrl'
            })

            .when('/service', {
                templateUrl: 'pages/service.html',
                controller: 'myCtrl'
            })

            .when('/faq', {
                templateUrl: 'pages/faq.html',
                controller: 'myCtrl'
            })

            .when('/tnc', {

                templateUrl: 'pages/tnc.html',
                controller: 'myCtrl'
            })

            .when('/view', {
                resolve: {
                    
                    "check": function ($location,$rootScope) {
                        if (!$rootScope.loggedin) {
                            alert("your need to login first");
                            $location.path('/home');
                        }
                        
                    }
                },
                templateUrl: 'pages/viewticket.html',
                controller: 'myCtrl'
            })

            .when('/busdetails', {
                templateUrl: 'pages/busdetails.html',
                controller: 'myCtrl'
            })


            .when('/cancel', {
                templateUrl: 'pages/cancelticket.html',
                controller: 'myCtrl'
            })

            .when('/payment', {
                resolve: {
                    "check": function ($location,$rootScope) {
                        if (!$rootScope.loggedin) {
                            alert("your need to login first");
                            $location.path('/home');
                        }

                    }
                },
                templateUrl: 'pages/payment.html',
                controller: 'myCtrl'
            })

            .when('/seatlayout', {
                resolve: {
                    "check": function ($location,$rootScope) {
                        if (!$rootScope.loggedin) {
                            alert("your need to login first");
                            $location.path("/home");
                        }

                    }
                },
                templateUrl: 'pages/seatlayout.html',
                controller: 'myCtrl'
            })

            .otherwise({ redirectTo: 'home' });
    })







webmodule.controller("ServiceController", function ($scope, $rootScope, $http, $location) {


$rootScope.val=true;


    $scope.Loginform = function (isValid) {

        if (isValid) {

            $scope.loginn();

        }
    }

    $scope.loginn = function () {

        $http({
            method: 'POST',
            url: 'http://localhost:8087/Final2/rest/listAll/loginn/' + $scope.Email + '/' + $scope.passw
        }).success(function (data) {

            if (data == 0) {
                alert("user dosen't exist");
            }
            else if (data == 1) {
                alert("password dosen't match");
            }

            else {
                $rootScope.loggedin = true;
                alert("successful");
                $location.path('/home');
            }






        });

    }




    $scope.Registerform = function (isValid) {

        if (isValid) {
            
            $scope.register();

        }
    }

    $scope.register = function () {
        
        $http({
            method: 'POST',
            url: 'http://localhost:8087/Final2/rest/listAll/register/' + $scope.fullname + '/' + $scope.phone + '/' + $scope.email + '/' + $scope.pass1 + '/' + $scope.gender
        }).success(function (data) {


            alert("DATA ADDED");



            $rootScope.result = data;


        });

    }



    $scope.form = {
        source: "",
        destination: "",
        day: "",


    };


    $rootScope.getdata = function (r) {


        //    	$rootScope.details={
        //    			
        //    			busno:$scope.r.busNo,
        //    			dtime:$scope.r.deptName,
        //    			atime: $scope.r.arrTime
        //    			
        //    	}

        $scope.busno = r.busNo;
        $scope.fare = r.fare;
        $scope.depttime = r.deptTime;
        $scope.atime = r.arrTIme;
        $scope.status = "confirm";
        $scope.email = "anurag@gmail.com";
        $scope.traveldate = "12-Nov-2018";
        $scope.bookingdate = "12-Nov-2018";

       

    }


    $scope.search = function () {

        $http({
            method: 'GET',
            url: 'http://localhost:8087/Final2/rest/listAll/search/' + $scope.form.source + '/' + $scope.form.destination + '/' + $scope.form.day
        }).success(function (data) {



            //    			alert("basic send")


            $rootScope.result = data;
            //                  alert('data' + JSON.stringify($rootScope.result));
            alert($rootScope.result.busNo);
        });

    }

    $scope.bdetail = function () {

        $http({
            method: 'GET',
            url: 'http://localhost:8087/Final2/rest/listAll/bdetail/' + $scope.busno + '/' + $scope.fare + '/' + $scope.status + '/' + $scope.email + '/' + $scope.bookingdate + '/' + $scope.traveldate + '/' + $scope.form.noofseats
        }).success(function (data) {

            $rootScope.routedata = data;


        });

    }



    $scope.route = function () {

        $http({
            method: 'GET',
            url: 'http://localhost:8087/Final2/rest/listAll/route/' + $scope.form.source + '/' + $scope.form.destination
        }).success(function (data) {

            $rootScope.routedata = data;


        });

    }



    $scope.seatinsert = function () {
        $scope.bookingid = Math.floor((Math.random() * 1000000000) + 1);
        alert( $scope.bookingid);
        $http({
            method: 'POST',
            url: 'http://localhost:8087/Final2/rest/listAll/Seatinsert/' + $scope.bookingid + '/' + $scope.pname + '/' + $scope.page + '/' + $scope.pgender + '/' + $scope.pseat + '/' + $scope.seatno
        }).success(function (data) {
            $rootScope.seatdata = data;
            alert("seat reserved");
        });

    }

});
